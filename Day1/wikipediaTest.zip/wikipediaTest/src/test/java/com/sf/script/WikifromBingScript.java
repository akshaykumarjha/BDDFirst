package com.sf.script;

import net.serenitybdd.jbehave.SerenityStories;

public class WikifromBingScript extends SerenityStories {

}
